function myFunc(){
	return "Hello World";
}

var	out = myFunc();

console.log (out);

//var selfExecute = 

